import FilesBlock from "./files-block.vue";
import PersonalAssistantBlock from "./personal-assistant-block.vue";
import FooterBlock from "./footer-block.vue";

export {
    FooterBlock,
    FilesBlock,
    PersonalAssistantBlock,
}