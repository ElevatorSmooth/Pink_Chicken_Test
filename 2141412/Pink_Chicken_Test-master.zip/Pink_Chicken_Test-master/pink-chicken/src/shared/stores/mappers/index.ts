import {mapFromApiToFileModel} from "./mapFromApiToFileModel";
import {mapFromApiToPersonalAsistant} from "./mapFromApiToPersonalAsistant";

export {
    mapFromApiToFileModel,
    mapFromApiToPersonalAsistant,
}