import CustomScrollbar from "./custom-scrollbar.vue";

export {
    CustomScrollbar,
}