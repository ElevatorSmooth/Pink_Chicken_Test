enum FileTypeEnum{
    Mediaplan,
    Report
}

export default FileTypeEnum;