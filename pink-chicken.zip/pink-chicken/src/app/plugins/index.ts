import Vuetify from "./vuetify"
import {loadFonts} from "./webfontloader"

export {
    Vuetify,
    loadFonts,
}


