import PersonalAssistant from "./PersonalAssistant.vue";

export { PersonalAssistant };